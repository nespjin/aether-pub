# Example Catalog for package:animations.

Run `flutter run --release` in this directory to launch the catalog on a device.
